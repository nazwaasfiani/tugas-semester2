<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
		//ke folder view/welcome_message
	}
	public function log()
	{
		$this->load->view('form_login');
	}
	public function register()
	{
		$this->load->view('registerform');
	}
	public function rumah()
	{
		$this->load->view('home');
	}
}