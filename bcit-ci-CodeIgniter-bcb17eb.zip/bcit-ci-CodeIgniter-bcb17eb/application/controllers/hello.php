<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

	
	public function data($data)
}
        echo $data
        //ke folder view/welcome_message

{
    public function tampil(){
        $data['judul1']"Halaman Tampil";
        $data['deskripsi']="ini deskripsi";

        //parsing data
        $this->load->view('tampil , $data');
    }
}
