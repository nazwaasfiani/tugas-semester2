<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Ini data</h1>

    <table border="1">
        <tr>
            <th>ID soal</th>
    I 
       <tr>
        <?php foreach ($query as $query) { ?>
            <tr>
                <td><?=$query->nik ?></td>

              </tr>
          <?php } ?>
        </table> 
</body>
</html>